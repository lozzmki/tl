Argparse tutorial
=================

Contents:

.. toctree::

   parsers
   arguments
   options
   mutexes
   commands
   defaults
   callbacks
   messages
   completions
   misc

This is a tutorial for `argparse <https://github.com/luarocks/argparse>`_, a feature-rich command line parser for Lua.
